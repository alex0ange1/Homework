grep -c "include" "$1"
