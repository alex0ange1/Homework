nano $(find ~ | fzf)
