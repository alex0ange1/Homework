ls main.cpp | entr -s "g++ -o main.cpp" &
