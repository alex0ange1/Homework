find . -type f -not -name "*.cpp" -and -not -name  "iloveonlycpp.sh" -exec rm {} \;
find . -type d -empty -delete
