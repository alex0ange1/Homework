find . -name "*.cpp" | xargs grep -l "include <vector>"
