find . -name "*.cpp" -exec zip -r -j answer.zip {} +
